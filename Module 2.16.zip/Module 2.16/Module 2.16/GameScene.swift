//
//  GameScene.swift
//  Module 2.16
//
//  Created by Александр Останин on 16.02.2021.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    let sizeAtStart: CGFloat = 15
    
    var enemySize: CGFloat = 15
    var score: Int = 0
    
    var destinationPoint: CGPoint?
    
    var player = SKShapeNode()
    
    var enemy = SKShapeNode()
    
    var enemyTwo: SKShapeNode? = nil
    
    var masterEnemy: SKShapeNode? = nil
    
    let scoreLabel = SKLabelNode()
    var gameOver = false
    
    var timer: [Timer] = []
    
    
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        initScene(view)
    }
    
    private func initScene(_ view: SKView) {
        
        backgroundColor = .gray
        
        enemySize = sizeAtStart
        score = 0
        
        player = SKShapeNode(circleOfRadius: sizeAtStart - 5)
        player.fillColor = .yellow
        player.strokeColor = .blue
        player.position = view.center
        addChild(player)
        
        enemy = SKShapeNode(circleOfRadius: sizeAtStart)
        enemy.fillColor = .red
        enemy.strokeColor = .black
        enemy.position = CGPoint(x: view.center.x, y: 60)
        addChild(enemy)
        
        enemyTwo = SKShapeNode(circleOfRadius: sizeAtStart)
        enemyTwo?.fillColor = .red
        enemyTwo?.strokeColor = .black
        enemyTwo?.position = CGPoint(x: 60, y: view.center.y)
        
        masterEnemy = SKShapeNode(circleOfRadius: sizeAtStart)
        masterEnemy?.fillColor = .red
        masterEnemy?.strokeColor = .yellow
        masterEnemy?.position = CGPoint(x: 60, y: view.center.y)
        
        scoreLabel.text = "Score: \(score)"
        scoreLabel.fontColor = .blue
        scoreLabel.horizontalAlignmentMode = .left
        scoreLabel.position = CGPoint(x: 16, y: self.size.height - 70)
        scoreLabel.fontSize = 30
        addChild(scoreLabel)
        
        
        timer.append(Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { [unowned self] _ in
            self.score += Int(1 + self.enemySize)
            self.scoreLabel.text = "Score: \(self.score)"
            
            
            if self.enemySize <= 30 {
                self.enemySize += 5
                let scale = self.enemySize / self.sizeAtStart
                let resize = SKAction.scale(to: scale, duration: 0.2)
                self.enemy.run(resize)
                self.enemyTwo?.run(resize)
                self.masterEnemy?.run(resize)
            } else if self.enemySize >= 60 {
                self.enemySize -= 5
                let scale = self.enemySize / self.sizeAtStart
                let resize = SKAction.scale(to: scale, duration: 0.2)
                self.enemy.run(resize)
                self.enemyTwo?.run(resize)
            }
            
        })
        
        timer.append(Timer.scheduledTimer(withTimeInterval: 30, repeats: true) {
            [unowned self] _ in
            self.addChild(enemyTwo!)
        })
        
        timer.append(Timer.scheduledTimer(withTimeInterval: 45, repeats: true) {
            [unowned self] _ in
            self.addChild(masterEnemy!)
        })
    }
    
    
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        destinationPoint = touches.first?.location(in: self)
    }
    
    func move(node: SKShapeNode, to: CGPoint?, speed: CGFloat) {
        guard let newPosition = to else {
            node.removeAllActions()
            return
        }
        
        if CGVector(a: node.position, b: newPosition).length < 2 {
            node.removeAllActions()
            return
        }
        
        let normalized = CGVector(dx: newPosition.x - node.position.x, dy: newPosition.y - node.position.y).normalized()
        let vector = CGVector(dx: normalized.dx * speed, dy: normalized.dy * speed)
        let move = SKAction.move(by: vector, duration: 0.5)
        node.run(move)
    }

//    func speedy () -> CGFloat {
//        var playerSpeed = 1
//        for _ in 0...8 {
//            playerSpeed += 1
//        }
//        return CGFloat(playerSpeed)
//    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        if gameOver { return }
        super.update(currentTime)
        move(node: player, to: destinationPoint, speed: 7)
        move(node: enemy, to: player.position, speed: 2)
        
        if let enemyTwoNo = enemyTwo, let masterEnemyNo = masterEnemy {
            move(node: enemyTwoNo, to: player.position, speed: 3)
            move(node: masterEnemyNo, to: player.position, speed: 4)
        }
        checkGameOver()
    }
    
    func checkGameOver() {
        if CGVector(a: player.position, b: enemy.position).length < sizeAtStart + enemySize - 1  {
            gameOver = true
            timer.forEach { $0.invalidate() }
            player.removeAllActions()
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) {
                [unowned self] _ in
                let scene = GameOverScene(size: self.size)
                scene.score = self.score
                let crossFade = SKTransition.crossFade(withDuration: 1)
                self.view?.presentScene(scene, transition: crossFade)
            }
        }
        if let enemyTwoNo = enemyTwo, let masterEnemyTwoNo = masterEnemy {
            if CGVector(a: player.position, b: enemyTwoNo.position).length < sizeAtStart + enemySize - 1 || CGVector(a: player.position, b: masterEnemyTwoNo.position).length < sizeAtStart + enemySize - 1 {
                gameOver = true
                timer.forEach { $0.invalidate() }
                player.removeAllActions()
                Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) {
                    [unowned self] _ in
                    let scene = GameOverScene(size: self.size)
                    scene.score = self.score
                    let crossFade = SKTransition.crossFade(withDuration: 1)
                    self.view?.presentScene(scene, transition: crossFade)
                }
            }
        }
    }
}

public extension CGVector {
    init(a: CGPoint, b: CGPoint) {
        self.init(dx: a.x - b.x, dy: a.y - b.y)
    }
    var length: CGFloat { return sqrt(dx * dx + dy * dy)}
    func normalized() -> CGVector {
        return length > 0 ? CGVector(dx: dx / length, dy: dy / length) : CGVector.zero
    }
}
