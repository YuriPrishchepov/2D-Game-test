//
//  GameOverScene.swift
//  Module 2.16
//
//  Created by Александр Останин on 25.04.2021.
//

import SpriteKit
import GameplayKit

class GameOverScene: SKScene {
    
    var score: Int = 0
    
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        
        let gameOverLabel = SKLabelNode(text: "GAME OVER")
        gameOverLabel.position = view.center
        gameOverLabel.fontSize = 55
        addChild(gameOverLabel)
        
        let scoreLabel = SKLabelNode(text: "score: \(self.score)")
        scoreLabel.position = CGPoint(x: view.center.x, y: view.center.y - 45)
        scoreLabel.fontSize = 35
        addChild(scoreLabel)
        
        backgroundColor = .blue
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        let scene = GameScene(size: size)
        view?.presentScene(scene, transition: .crossFade(withDuration: 1))
    }
}
