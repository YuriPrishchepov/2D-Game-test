//
//  GameViewController.swift
//  Module 2.16
//
//  Created by Александр Останин on 16.02.2021.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let skView = view as! SKView
        let scene =  GameScene(size: skView.frame.size)
        
        skView.presentScene(scene)
        
    }
}
